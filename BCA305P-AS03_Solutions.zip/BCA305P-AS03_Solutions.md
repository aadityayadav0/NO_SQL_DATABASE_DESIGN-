# BCA305P-AS03 — NoSQL Database Design, Lab Sheet 5 Solutions

**Q1–Q10: Riak KV | Q11–Q15: Neo4j**

> These are lab examples. Installations and Riak API options vary by version. Run commands in a configured environment and capture your own actual screenshots. The output is illustrative, not a claim that commands were executed.

## Q1. Riak KV student bucket CRUD

Install a supported Riak KV release for your Linux distribution, start the service, and verify the node is running. Example local HTTP API:

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/students/student101 -H 'Content-Type: application/json' -d '{"id":"student101","name":"Aman","course":"BCA","year":2}'
curl -i http://127.0.0.1:8098/riak/students/student101
curl -i -X PUT http://127.0.0.1:8098/riak/students/student101 -H 'Content-Type: application/json' -d '{"id":"student101","name":"Aman Kumar","course":"BCA","year":3}'
curl -i -X DELETE http://127.0.0.1:8098/riak/students/student101
```
`students` is the bucket, `student101` the key, and the JSON body the value. PUT creates/replaces, GET retrieves, DELETE removes.

## Q2. User sessions

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/user_sessions/sess-9001 -H 'Content-Type: application/json' -d '{"session_id":"sess-9001","user_id":"u101","login_time":"2026-10-29T10:00:00Z","status":"active"}'
curl -i http://127.0.0.1:8098/riak/user_sessions/sess-9001
```
Session ID is the key. Add expiry and secure session handling in application logic or use expiry features supported by your version.

## Q3. User profiles and preferences

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/user_profiles/user101 -H 'Content-Type: application/json' -d '{"name":"Riya","email":"riya@example.com","city":"Saharanpur","preferences":{"language":"English","theme":"dark","notifications":true}}'
curl -i http://127.0.0.1:8098/riak/user_profiles/user101
```
PUT stores the profile; GET retrieves it.

## Q4. Shopping cart

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/carts/user101 -H 'Content-Type: application/json' -d '{"user_id":"user101","items":[{"product_id":"P1","quantity":2,"price":100}],"total":200}'
curl -i -X PUT http://127.0.0.1:8098/riak/carts/user101 -H 'Content-Type: application/json' -d '{"user_id":"user101","items":[{"product_id":"P1","quantity":3,"price":100},{"product_id":"P2","quantity":1,"price":50}],"total":350}'
curl -i http://127.0.0.1:8098/riak/carts/user101
curl -i -X DELETE http://127.0.0.1:8098/riak/carts/user101
```
To remove one product, GET the cart, remove the item and recalculate the total in application code, then PUT the updated cart. Handle concurrent updates using version/context support.

## Q5. Values and key-value model

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/demo/string1 -H 'Content-Type: text/plain' --data-binary 'Hello Riak'
curl -i -X PUT http://127.0.0.1:8098/riak/demo/user1 -H 'Content-Type: application/json' -d '{"name":"Neha","active":true}'
curl -i -X PUT http://127.0.0.1:8098/riak/demo/colors -H 'Content-Type: application/json' -d '["red","green","blue"]'
curl http://127.0.0.1:8098/riak/demo/string1
curl http://127.0.0.1:8098/riak/demo/user1
curl http://127.0.0.1:8098/riak/demo/colors
```
A bucket groups objects, a key identifies an object, and a value contains its bytes. Content type/application logic determine interpretation.

## Q6. Read/write quorum and consistency

Riak APIs commonly support request options such as `r`, `w`, and `dw`; accepted values vary by release.

```bash
curl -i -X PUT 'http://127.0.0.1:8098/riak/students/student202?w=quorum&dw=quorum' -H 'Content-Type: application/json' -d '{"id":"student202","name":"Karan"}'
curl -i 'http://127.0.0.1:8098/riak/students/student202?r=quorum'
```
Confirm valid option values for your version. Higher quorums generally require more replicas to respond, improving confidence but potentially reducing availability during failures. Quorums are not a universal strict-transaction guarantee.

## Q7. Scaling demonstration

```bash
for i in $(seq 1 1000); do
  curl -s -o /dev/null -X PUT "http://127.0.0.1:8098/riak/metrics/page-$i" -H 'Content-Type: application/json' -d "{\"page_id\":\"page-$i\",\"views\":$i}"
done
curl -i -X PUT http://127.0.0.1:8098/riak/audit/event-1 -H 'Content-Type: application/json' -d '{"type":"login","user":"u1"}'
```
Riak partitions key space and distributes partitions/replicas across nodes. A genuine scaling demonstration requires a multi-node cluster; one local node only demonstrates the data model.

## Q8. Transaction-like shopping workflow

1. GET the cart.
2. Validate stock and quantity.
3. Update items and calculate total in application code.
4. PUT the new value using version/context handling to detect concurrent changes.
5. GET again to verify.

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/carts/user202 -H 'Content-Type: application/json' -d '{"user_id":"user202","items":[{"product_id":"P3","quantity":2,"price":75}],"total":150}'
curl -i http://127.0.0.1:8098/riak/carts/user202
```
Riak KV is not a general multi-object ACID transaction database. Related writes can partially succeed; applications need retries, idempotency, conflict handling, and reconciliation.

## Q9. Query-by-data

```bash
curl -s -X PUT http://127.0.0.1:8098/riak/user_records/u1 -H 'Content-Type: application/json' -d '{"name":"Aman","city":"Saharanpur","age":21,"preferences":["music","cricket"]}'
curl -s -X PUT http://127.0.0.1:8098/riak/user_records/u2 -H 'Content-Type: application/json' -d '{"name":"Sara","city":"Delhi","age":23,"preferences":["reading"]}'
```
Basic KV GET looks up bucket/key, not arbitrary JSON attributes. For a small dataset, retrieve known keys and filter in Python:

```python
import requests
base = "http://127.0.0.1:8098/riak/user_records"
users = []
for key in ["u1", "u2"]:
    response = requests.get(f"{base}/{key}", timeout=5)
    if response.ok:
        users.append(response.json())
print([u for u in users if u.get("city") == "Saharanpur" and u.get("age", 0) >= 18])
```
For large datasets, use a supported search/index feature or maintain lookup keys.

## Q10. Set operations

```bash
curl -i -X PUT http://127.0.0.1:8098/riak/user_interests/u1 -H 'Content-Type: application/json' -d '["music","cricket","travel"]'
curl -i -X PUT http://127.0.0.1:8098/riak/user_interests/u2 -H 'Content-Type: application/json' -d '["cricket","reading","travel"]'
curl http://127.0.0.1:8098/riak/user_interests/u1
curl http://127.0.0.1:8098/riak/user_interests/u2
```

```python
a = {"music", "cricket", "travel"}
b = {"cricket", "reading", "travel"}
a.add("coding")        # add
a.discard("music")     # remove
print("cricket" in a)  # membership
print(a & b)           # common elements
```
For distributed concurrent updates, use Riak's supported CRDT set API and causal context rather than overwriting JSON arrays.

## Q11. Neo4j Student, Course, Department graph

Install Neo4j Desktop or a supported Neo4j Server, start a database, open Neo4j Browser and run:

```cypher
CREATE
  (s1:Student {studentId:'S101', name:'Aman'}),
  (s2:Student {studentId:'S102', name:'Riya'}),
  (c1:Course {courseId:'C01', title:'NoSQL Database Design'}),
  (d1:Department {name:'Computer Applications'}),
  (s1)-[:ENROLLED_IN]->(c1),
  (s2)-[:ENROLLED_IN]->(c1),
  (s1)-[:BELONGS_TO]->(d1),
  (s2)-[:BELONGS_TO]->(d1);
MATCH (s:Student)-[r]->(n) RETURN s,r,n;
```
Neo4j Browser can visualize the returned graph.

## Q12. Social network

```cypher
CREATE
  (a:Person {name:'Aman'}),
  (b:Person {name:'Riya'}),
  (c:Person {name:'Karan'}),
  (co:Company {name:'ABC Tech'}),
  (a)-[:FRIENDS_WITH]->(b),
  (c)-[:FOLLOWS]->(a),
  (a)-[:WORKS_AT]->(co);
```

```cypher
MATCH (:Person {name:'Aman'})-[:FRIENDS_WITH]-(friend:Person)
RETURN friend.name;
```

```cypher
MATCH (follower:Person)-[:FOLLOWS]->(:Person {name:'Aman'})
RETURN follower.name;
```
The friends query treats `FRIENDS_WITH` as undirected; `FOLLOWS` is directional.

## Q13. E-commerce graph

```cypher
CREATE
  (c:Customer {customerId:'CU1', name:'Aman'}),
  (p1:Product {productId:'P1', name:'Keyboard', price:700}),
  (p2:Product {productId:'P2', name:'Mouse', price:400}),
  (cat:Category {name:'Accessories'}),
  (o:Order {orderId:'O100', date:'2026-10-29'}),
  (c)-[:PLACED]->(o),
  (o)-[:CONTAINS {quantity:1}]->(p1),
  (o)-[:CONTAINS {quantity:2}]->(p2),
  (p1)-[:IN_CATEGORY]->(cat),
  (p2)-[:IN_CATEGORY]->(cat);
```

```cypher
MATCH (:Customer {customerId:'CU1'})-[:PLACED]->(:Order)-[line:CONTAINS]->(p:Product)
RETURN p.name AS product, line.quantity AS quantity, p.price AS unitPrice;
```

## Q14. Transactions, consistency, availability

```cypher
CREATE (:Product {productId:'TX1', name:'Notebook', stock:10});
MATCH (p:Product {productId:'TX1'}) SET p.stock = p.stock - 1;
MATCH (p:Product {productId:'TX1'}) RETURN p;
```
For an actual multi-step atomic transaction, execute statements through a Neo4j driver transaction function (or a Browser transaction workflow supported by the version); throw an error on failure to roll back. Delete example, only when intended:

```cypher
MATCH (p:Product {productId:'TX1'}) DELETE p;
```
Neo4j provides ACID transaction semantics for committed changes. Availability depends on deployment topology, replication, failover, and configuration.

## Q15. Python Neo4j CRUD application

Install the official driver:

```bash
pip install neo4j
```
Set `NEO4J_URI`, `NEO4J_USERNAME`, and `NEO4J_PASSWORD`, then save as `neo4j_crud.py`:

```python
import os
from neo4j import GraphDatabase

driver = GraphDatabase.driver(
    os.environ["NEO4J_URI"],
    auth=(os.environ.get("NEO4J_USERNAME", "neo4j"), os.environ["NEO4J_PASSWORD"])
)

def create_student(tx, sid, name, course):
    tx.run("MERGE (s:Student {studentId:$sid}) SET s.name=$name, s.course=$course",
           sid=sid, name=name, course=course)

def read_student(tx, sid):
    result = tx.run("MATCH (s:Student {studentId:$sid}) RETURN s.studentId AS id, s.name AS name, s.course AS course",
                    sid=sid)
    return [record.data() for record in result]

def update_student(tx, sid, name):
    tx.run("MATCH (s:Student {studentId:$sid}) SET s.name=$name", sid=sid, name=name)

def delete_student(tx, sid):
    tx.run("MATCH (s:Student {studentId:$sid}) DETACH DELETE s", sid=sid)

with driver.session() as session:
    session.execute_write(create_student, "S900", "Aman", "BCA")
    print("READ:", session.execute_read(read_student, "S900"))
    session.execute_write(update_student, "S900", "Aman Yadav")
    print("UPDATED:", session.execute_read(read_student, "S900"))
    session.execute_write(delete_student, "S900")
    print("AFTER DELETE:", session.execute_read(read_student, "S900"))
driver.close()
```

Expected output (format may vary):

```text
READ: [{'id': 'S900', 'name': 'Aman', 'course': 'BCA'}]
UPDATED: [{'id': 'S900', 'name': 'Aman Yadav', 'course': 'BCA'}]
AFTER DELETE: []
```

Graph databases are useful for social networks, recommendations, fraud analysis and knowledge graphs because relationships can be traversed directly. Scaling and availability depend on edition, deployment, indexes and workload.

## Submission checklist

- Replace sample values if needed.
- Run examples in a configured Riak/Neo4j environment and capture real screenshots.
- Output shown is illustrative; it does not claim commands were executed.
- Verify installation commands and API parameters against your installed version.
