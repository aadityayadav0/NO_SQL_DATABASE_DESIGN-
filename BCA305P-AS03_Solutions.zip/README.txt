BCA305P-AS03 Lab Sheet 5 solutions: Q1-Q10 Riak KV, Q11-Q15 Neo4j. See BCA305P-AS03_Solutions.md.
