# BCA305P-AS01 — Lab Sheet 4 Solutions
Solutions only; run commands in an installed/running HBase or Cassandra lab environment.

## Apache HBase

### Q1 Student table, five records
```ruby
create 'Student','personal','academic'
put 'Student','S001','personal:name','Aarav Sharma'
put 'Student','S001','academic:course','BCA'
put 'Student','S002','personal:name','Diya Verma'
put 'Student','S002','academic:course','BCA'
put 'Student','S003','personal:name','Kabir Singh'
put 'Student','S003','academic:course','BCA'
put 'Student','S004','personal:name','Anaya Gupta'
put 'Student','S004','academic:course','BSc'
put 'Student','S005','personal:name','Reyansh Kumar'
put 'Student','S005','academic:course','BCA'
scan 'Student'
```
Start with `start-hbase.sh`, then `hbase shell`.

### Q2 Employee CRUD
```ruby
create 'Employee','info','job'
put 'Employee','E101','info:name','Rohan'
put 'Employee','E101','job:role','Developer'
get 'Employee','E101'
scan 'Employee'
put 'Employee','E101','job:role','Senior Developer'
delete 'Employee','E101','info:name'
deleteall 'Employee','E101'
```

### Q3 Event logging
```ruby
create 'EventLog','event','user','state'
put 'EventLog','EVT001','event:timestamp','2026-10-15T10:00:00Z'
put 'EventLog','EVT001','event:type','LOGIN'
put 'EventLog','EVT001','user:user_id','U101'
put 'EventLog','EVT001','state:status','SUCCESS'
get 'EventLog','EVT001'
```

### Q4 CMS CRUD
```ruby
create 'CMS','content','author','metadata'
put 'CMS','C001','content:title','NoSQL Basics'
put 'CMS','C001','content:body','Introduction to NoSQL'
put 'CMS','C001','author:name','Aaditya'
put 'CMS','C001','metadata:status','draft'
get 'CMS','C001'
put 'CMS','C001','metadata:status','published'
delete 'CMS','C001','content:body'
get 'CMS','C001'
```

### Q5 Blogging platform, three blogs
```ruby
create 'Blog','details','author','comments'
put 'Blog','B001','details:title','HBase Intro'
put 'Blog','B001','author:name','Aarav'
put 'Blog','B002','details:title','Cassandra Basics'
put 'Blog','B002','author:name','Diya'
put 'Blog','B003','details:title','Row Key Design'
put 'Blog','B003','author:name','Kabir'
scan 'Blog'
get 'Blog','B002'
```

### Q6 Column families and qualifiers
```ruby
create 'Library','book','publisher','availability'
put 'Library','ISBN001','book:title','Database Systems'
put 'Library','ISBN001','book:author','A Kumar'
put 'Library','ISBN001','publisher:name','Tech Press'
put 'Library','ISBN001','availability:copies','12'
describe 'Library'
scan 'Library'
```
Families are declared at table creation; qualifiers such as `title` and `author` belong to a family and can vary by row.

### Q7 Website counters
```ruby
create 'WebsiteCounter','views'
incr 'WebsiteCounter','home','views:count',1
incr 'WebsiteCounter','home','views:count',1
incr 'WebsiteCounter','products','views:count',1
get 'WebsiteCounter','home'
get 'WebsiteCounter','products'
```

### Q8 Session TTL
```ruby
create 'UserSessions', {NAME => 'session', TTL => 3600}
put 'UserSessions','SID1001','session:user_id','U101'
put 'UserSessions','SID1001','session:status','active'
get 'UserSessions','SID1001'
describe 'UserSessions'
```
TTL is in seconds (one hour). Physical cleanup can happen later during compaction.

### Q9 Scalable row keys
```ruby
create 'Orders','order'
put 'Orders','03#ORD1001','order:customer','C101'
put 'Orders','07#ORD1002','order:customer','C102'
put 'Orders','12#ORD1003','order:customer','C103'
scan 'Orders'
```
A deterministic salt/bucket prefix distributes writes; avoid only increasing keys that can hotspot one region.

### Q10 Regions and RegionServers
```ruby
create 'RegionDemo','data', {NUMREGIONS => 3, SPLITALGO => 'HexStringSplit'}
describe 'RegionDemo'
put 'RegionDemo','1000','data:value','A'
put 'RegionDemo','8000','data:value','B'
put 'RegionDemo','F000','data:value','C'
scan 'RegionDemo'
```
Inspect region assignments in the HBase UI (often port 16010). RegionServers host regions and serve reads/writes; regions split and can be reassigned as data grows.

## Apache Cassandra

Open shell with `cqlsh`.

### Q11 CollegeDB and five students
```sql
CREATE KEYSPACE CollegeDB WITH replication={'class':'SimpleStrategy','replication_factor':1};
USE CollegeDB;
CREATE TABLE Students(student_id text PRIMARY KEY,name text,city text,course text,semester int);
INSERT INTO Students VALUES ('S001','Aarav Sharma','Saharanpur','BCA',3);
INSERT INTO Students VALUES ('S002','Diya Verma','Meerut','BCA',3);
INSERT INTO Students VALUES ('S003','Kabir Singh','Delhi','BCA',4);
INSERT INTO Students VALUES ('S004','Anaya Gupta','Noida','BSc',2);
INSERT INTO Students VALUES ('S005','Reyansh Kumar','Haridwar','BCA',5);
SELECT * FROM Students;
```
RF=1 is for a single-node lab, not production.

### Q12 Employees CRUD
```sql
CREATE TABLE Employees(employee_id text PRIMARY KEY,name text,department text,salary decimal);
INSERT INTO Employees VALUES ('E101','Rohan','IT',45000);
SELECT * FROM Employees;
UPDATE Employees SET salary=52000 WHERE employee_id='E101';
DELETE FROM Employees WHERE employee_id='E101';
```

### Q13 Events by user/time
```sql
CREATE TABLE EventsByUser(user_id text,event_time timestamp,event_id text,event_type text,status text,
 PRIMARY KEY ((user_id),event_time,event_id)) WITH CLUSTERING ORDER BY (event_time DESC);
INSERT INTO EventsByUser VALUES ('U101','2026-10-15T10:00:00Z','EV1','LOGIN','SUCCESS');
INSERT INTO EventsByUser VALUES ('U101','2026-10-15T11:00:00Z','EV2','PAYMENT','FAILED');
SELECT * FROM EventsByUser WHERE user_id='U101'
 AND event_time >= '2026-10-15T00:00:00Z' AND event_time < '2026-10-16T00:00:00Z';
```

### Q14 Consistency ONE, QUORUM, ALL
```sql
CREATE KEYSPACE ConsistencyDemo WITH replication={'class':'SimpleStrategy','replication_factor':3};
USE ConsistencyDemo;
CREATE TABLE Demo(id text PRIMARY KEY,value text);
CONSISTENCY ONE;
INSERT INTO Demo VALUES ('1','example');
SELECT * FROM Demo WHERE id='1';
CONSISTENCY QUORUM;
SELECT * FROM Demo WHERE id='1';
CONSISTENCY ALL;
SELECT * FROM Demo WHERE id='1';
```
Compare these on a cluster with three replicas; single-node tests cannot demonstrate real replica quorum behavior.

### Q15 Column-oriented Event Logging application
```sql
CREATE KEYSPACE EventApp WITH replication={'class':'SimpleStrategy','replication_factor':1};
USE EventApp;
CREATE TABLE EventLog(user_id text,event_date date,event_time timestamp,event_id text,event_type text,status text,
 PRIMARY KEY ((user_id,event_date),event_time,event_id)) WITH CLUSTERING ORDER BY (event_time DESC);
INSERT INTO EventLog VALUES ('U101','2026-10-15','2026-10-15T10:00:00Z','EV1','LOGIN','SUCCESS');
SELECT * FROM EventLog WHERE user_id='U101' AND event_date='2026-10-15';
UPDATE EventLog SET status='REVIEWED' WHERE user_id='U101' AND event_date='2026-10-15'
 AND event_time='2026-10-15T10:00:00Z' AND event_id='EV1';
DELETE FROM EventLog WHERE user_id='U101' AND event_date='2026-10-15'
 AND event_time='2026-10-15T10:00:00Z' AND event_id='EV1';
```
Consistency is set per operation; availability depends on reachable replicas; Cassandra is query-driven and scales by adding nodes. Lightweight transactions exist but are not general multi-row ACID transactions.
